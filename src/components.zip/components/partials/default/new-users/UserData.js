export const newUserData = [
  {
    initial: "AB",
    theme: "purple-dim",
    name: "Abu Ibn Ishtiak",
    email: "info@softnio.com",
  },
  {
    initial: "SW",
    theme: "danger-dim",
    name: "Sharon Walker",
    email: "sharon-90@example.com",
  },
  {
    initial: "GO",
    theme: "warning-dim",
    name: "Gloria Oliver",
    email: "gloria_72@example.com",
  },
  {
    initial: "PS",
    theme: "success-dim",
    name: "Phillip Sullivan",
    email: "phillip-85@example.com",
  },
];
