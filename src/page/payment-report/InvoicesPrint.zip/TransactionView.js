import React, { useState, useEffect } from "react";
import Head from "../../layout/head/Head";
import Content from "../../layout/content/Content";
import { Link } from "react-router-dom";
import LogoDark from "../../images/logo.png";
import { format } from 'date-fns'

import {
  Block,
  BlockHead,
  BlockTitle,
  BlockBetween,
  BlockHeadContent,
  Icon,
  BlockDes,
} from "../../components/Component";
import { Button } from "reactstrap";
import { transactionReportView} from "../../app/api";
import { toast, ToastContainer } from "react-toastify";
import { useParams } from "react-router";
import Loader from "../../app/Loader";


const PaymentDetail = () => {
  const {transactionid} = useParams();
  const [loading, setLoading] = useState(false);
  const [cdata, setData] = useState(null);
  // Changing state value when searching name
  const getReport = async () => {
    setLoading(true);
    const res = await transactionReportView(atob(transactionid));
    console.log(res);
    if(res.data) {
      setData(res.data)
    }
    setLoading(false);
  }
  useEffect( () => {
    getReport();
  }, []);

  return (
    <React.Fragment>
      <Head title="Payment Report"></Head>
      <Content>
      <Loader visible={loading} />
        <BlockHead size="sm">
          <BlockBetween>
          <BlockHeadContent>
                <BlockTitle>
                  Invoice <strong className="text-primary small"> #  {cdata !== null ? cdata.transaction_id: '0' } </strong>
                </BlockTitle>
                <BlockDes className="text-soft">
                  <ul className="list-inline">
                    <li>
                      Created At: <span className="text-base"> {cdata !== null ? cdata.created_at: '0' } </span>
                    </li>
                  </ul>
                </BlockDes>
              </BlockHeadContent>
          </BlockBetween>
        </BlockHead>
        <Block>
            <div className="invoice">
              <div className="invoice-action">

              <Link  target="_blank">
                  <Button size="md" color="primary" outline className="btn btn-white btn-outline-light" style={{'margin': '10px'}} >
                  <Icon name="download-cloud"></Icon>
                   <span>Download PDF</span>
                  </Button>
                </Link>        
    
              <Link to={`${process.env.PUBLIC_URL}/transaction-print/${transactionid}`} target="_blank">
                  <Button size="md" color="primary" outline className="btn btn-white btn-outline-light">
                   <Icon name="printer-fill"></Icon> 
                   <span>Print</span>
                  </Button>
                </Link>
              </div>
              <div className="invoice-wrap">
                <div className="invoice-brand text-left">
                      <img src={LogoDark} alt="" />
                </div>
                <hr/>
                <div className="text-center">
                <strong className="text-primary small">PAYMENT RECEIPT</strong>
                </div>
                <hr/>
                <div className="invoice-head">
                  <div className="invoice-contact">
                    <span className="overline-title">Invoice To</span>
                    <div className="invoice-contact-info">
                      <h4 className="title">{cdata !== null ? cdata.name: '0' } </h4>
                      <ul className="list-plain">
                        <li>
                          <Icon name="map-pin-fill"></Icon>
                          <span>{cdata !== null ? cdata.address_line1: '0' }
                            <br />
                            {cdata !== null ? cdata.address_line2: '0' }
                            {cdata !== null ? cdata.city: '0' }<br />
                            {cdata !== null ? cdata.state: '0' }<br />
                            {cdata !== null ? cdata.country: '0' }
                          </span>
                        </li>
                        <li>
                          <Icon name="call-fill"></Icon>
                          <span>{cdata !== null ? cdata.phone: '0' }</span>
                        </li>
                        <li>
                          <Icon name="mail"></Icon>
                          <span>{cdata !== null ? cdata.email: '0' }</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="invoice-contact">
                  <span className="overline-title">Company Info</span>
                    <div className="invoice-contact-info">
                      <h4 className="title"> 7SearchPPC </h4>
                      <ul className="list-plain">
                        <li>
                          <Icon name="mail"></Icon>
                          <span> contact@7searchppc.com  </span>
                        </li>
                        <li>
                        <strong className="text-primary small"> GSTIN  </strong>
                          <span> : 09AAECL2613D1ZW</span> <br />
                          <strong className="text-primary small">( LOGELITE PRIVATE LIMITED ) </strong>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="invoice-contact">
                   
                    <ul className="list-plain">
                      <li className="invoice-id">
                      <span> INVOICE ID</span>:<span> <strong>  {cdata !== null ? cdata.transaction_id: '0' } </strong> </span>
                      </li>
                      <li className="invoice-date">
                        <span>Date</span>:<span> {cdata !== null ? cdata.created_at: '0'} </span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="invoice-bills">
                  <div className="table-responsive">
                    <table className="table table-striped">
                      <thead>
                        <tr>
                          <th className="w-150px">Payment Mode</th>
                          <th className="w-60">Description</th>
                          <th>SAC</th>
                          <th>Total Amount</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>{cdata !== null ? cdata.payment_mode: '0' }</td>
                          <td>{cdata !== null ? cdata.remark: '0' }</td>
                          <td>998365</td>
                          <td>${cdata !== null ? cdata.amount: '0' }</td>
                        </tr>
                      </tbody>
                      <tfoot>
                        <tr>
                          <td colSpan="2"></td>
                          <td >Subtotal</td>
                          <td>${cdata !== null ? cdata.amount: '0' }</td>
                        </tr>
                        <tr>
                          <td colSpan="2"></td>
                          <td >Processing fee</td>
                          <td> .... </td>
                        </tr>
                        <tr>
                          <td colSpan="2"></td>
                          <td >TAX</td>
                          <td>${cdata !== null ? cdata.fees_tax: '0' }</td>
                        </tr>
                        <tr>
                          <td colSpan="2"></td>
                          <td >Grand Total</td>
                          <td>${cdata !== null ? cdata.payble_amt: '0' }</td>
                        </tr>
                        <tr>
                          <td colSpan="2"></td>
                          <td> Amount Paid (USD) </td>
                          <td>${cdata !== null ? cdata.payble_amt: '0' }</td>
                        </tr>
                      </tfoot>
                    </table>
                    <div className="nk-notes fs-14px">
                    <strong className="text-primary small"> Terms & Conditions </strong>
                    </div>
                    <div className="nk-notes fs-13px ">
                    <strong className="text-primary small">1. </strong> Please read respective agreement carefully before you proceed to any further actions with 7searchppc.com. It is mandatory for users to go through each and every statement mentioned on the agreement. Once you are satisfied with the terms and conditions then you may proceed ahead for other actions.
                    </div>
                    <br />
                    <div className="nk-notes fs-13px ">
                    <strong className="text-primary small">2. </strong>The amount you added on your 7searchppc wallet, it is only consumable to advertisement’s campaigns. The money cannot be refundable in any manner to the individual’s banks or any other personal wallet. The money once spent on 7searchppc wallet will be used for advertisements and respective campaigns of the user. Any sort of refund is not permitted once purchase is done by the user.
                    </div>
                    <br />
                    <div className="nk-notes fs-13px ">
                    <strong className="text-primary small">3. </strong>The price included in the wallet will be calculated and processed as per INR. Also, the price includes in rupees as per the current exchange rates.
                    </div>
                    <br />
                    <div className="nk-notes fs-13px ">
                    <strong className="text-primary small">4. </strong>The price does not include any extra charges of the wallet amount. You will only have to pay as much as required to run your advertisement’s campaign. No extra amount will be deducted from your wallet so far.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Block>
        
    
        <ToastContainer/>
      </Content>
    </React.Fragment>
  );
};

export default PaymentDetail;
